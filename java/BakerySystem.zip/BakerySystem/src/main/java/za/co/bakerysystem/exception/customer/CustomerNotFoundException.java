package za.co.bakerysystem.exception.customer;

public class CustomerNotFoundException extends Exception {

    public CustomerNotFoundException(String msg) {
        super(msg);
    }

}
