package za.co.bakerysystem.exception.shoppingcart;

public class ShoppingCartNotFoundException extends Exception {

    public ShoppingCartNotFoundException(String message) {
        super(message);
    }
}
