package za.co.bakerysystem.exception.recipe;

public class DuplicateRecipeException extends Exception {

    public DuplicateRecipeException(String msg) {
        super(msg);
    }

}
