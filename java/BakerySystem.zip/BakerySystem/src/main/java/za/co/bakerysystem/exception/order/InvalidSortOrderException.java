package za.co.bakerysystem.exception.order;

public class InvalidSortOrderException extends Exception {

    public InvalidSortOrderException(String message) {
        super(message);
    }
}
