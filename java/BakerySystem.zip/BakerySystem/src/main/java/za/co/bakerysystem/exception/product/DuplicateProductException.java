package za.co.bakerysystem.exception.product;

public class DuplicateProductException extends Exception {

    public DuplicateProductException(String msg) {
        super(msg);
    }
}
