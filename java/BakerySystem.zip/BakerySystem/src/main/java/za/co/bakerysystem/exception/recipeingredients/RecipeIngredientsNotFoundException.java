package za.co.bakerysystem.exception.recipeingredients;

public class RecipeIngredientsNotFoundException extends Exception {

    public RecipeIngredientsNotFoundException(String message) {
        super(message);
    }
}
