package za.co.bakerysystem.exception.paymentType;

public class PaymentTypeNotFoundException extends Exception {

    public PaymentTypeNotFoundException(String message) {
        super(message);
    }
}
