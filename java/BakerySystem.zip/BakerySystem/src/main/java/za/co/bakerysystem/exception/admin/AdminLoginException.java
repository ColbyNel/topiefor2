package za.co.bakerysystem.exception.admin;

public class AdminLoginException extends Exception {

    public AdminLoginException(String message) {
        super(message);
    }
}
