package za.co.bakerysystem.exception.order;

public class OrderUpdateException extends Exception {

    public OrderUpdateException(String message) {
        super(message);
    }
}
