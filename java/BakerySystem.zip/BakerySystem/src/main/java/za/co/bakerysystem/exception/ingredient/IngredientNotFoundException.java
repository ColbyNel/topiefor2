package za.co.bakerysystem.exception.ingredient;

public class IngredientNotFoundException extends Exception {

    public IngredientNotFoundException(String message) {
        super(message);
    }

}
