package za.co.bakerysystem.exception.order;

public class OrderDeletionException extends Exception {

    public OrderDeletionException(String message) {
        super(message);
    }
}
