package za.co.bakerysystem.exception.admin;

public class AdminNotFoundException extends Exception{

    public AdminNotFoundException(String msg) {
        super(msg);
    }
    
}
