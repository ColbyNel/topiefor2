package za.co.bakerysystem.restapi;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("api")
public class MyRestApp extends Application{

}
