package za.co.bakerysystem.exception.customer;

public class DuplicateIdException extends Exception {

    public DuplicateIdException(String msg) {
        super(msg);
    }
}
