package za.co.bakerysystem.exception.customer;

public class CustomerLoginException extends Exception {

    public CustomerLoginException(String message) {
        super(message);
    }
}
