package za.co.bakerysystem.exception.paymentType;

public class DuplicatePaymentTypeException extends Exception {

    public DuplicatePaymentTypeException(String msg) {
        super(msg);
    }

}
