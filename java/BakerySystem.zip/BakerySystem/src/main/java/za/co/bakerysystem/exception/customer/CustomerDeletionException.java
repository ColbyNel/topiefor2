package za.co.bakerysystem.exception.customer;

public class CustomerDeletionException extends Exception {

    public CustomerDeletionException(String msg) {
        super(msg);
    }

}
